import java.io.Serializable;

public class Person implements Employable{
	private String firstName;
	private String lastName;
	private String socialSecurityNumber;
	

	
	public Person(String firstName, String lastName, String socialSecurityNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		// TODO if socialSecurityNumber is null or "", set it to ""
		
	}
	
	
	
	public String getFirstName() {
		//TODO
		return "";
	}



	public String getLastName() {
		// TODO
		return "";
	}



	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}



	public boolean canWork() {
		
		// TODO person can work (return true), unless their SSN is ""
		return false;
	}
	
	// If a person can work, this person can work at a university as well
	public boolean canWorkAtUniversity() {
		
		// TODO
		return false;
	}

// TODO keep in mind that it needs to reflect Student ability to work at the university
// >Person [firstName=Bo, lastName=Xa, socialSecurityNumber=123-00-1234, canWork=true, canWorkAtUniversity=true]<
// >Person [firstName=Alex, lastName=Smith, socialSecurityNumber=, canWork=false, canWorkAtUniversity=false]<
// >Person [firstName=Alex, lastName=Smith, socialSecurityNumber=, canWork=false, canWorkAtUniversity=true]< 
// in the line above, when we use toString for a Student, we want to indicate that Student can work at the university
	@Override
	public String toString() {
		//TODO
		return "";
	}
	
}
