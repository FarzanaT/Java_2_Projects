public interface Employable {
	boolean canWork();
	boolean canWorkAtUniversity();

}