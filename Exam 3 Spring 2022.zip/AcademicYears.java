import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

// System has to stop adding the same student twice to a class
// and adding the same course twice to a student's courses
public class AcademicYears {
	//TODO make a good choice of your structures
	
	public AcademicYears() {
		// TODO
	}
	
	public void add(Student student, Course course) {
		//TODO add Student to the Course
			
	}
	

	
	public ArrayList<Student> getStudentsTaking(Course course) {
		//TODO return students taking a given course
		// or an empty list, if nobody is taking this course
		// (you wish you had that option for CS2334 :)
		return null;
			
	}
	
	public LinkedList<Course> getCouresForStudent(Student student) {
		//TODO return courses that this student has taken
		// or an empty list, if none 
		// (you wish you had all of the courses by now)
		return null;
	}
	
	public ArrayList<Student> getStudentsTaking(List<Course> courses) {
		//TODO return a group of students that have taken courses
		// given in a list courses
		// I hope you have found some friends in this class, and you will take 
		// more classes together. If not - best of luck in wherever you will go.

		return null;

	}
	
	
	

}
