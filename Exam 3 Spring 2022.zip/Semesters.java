
public enum Semesters {
	SPRING,
	SUMMER,
	FALL
}
