
public class Semester {
	private Semesters semester;
	private int year;
	
	public Semester(Semesters semester, int year) {
		
		this.semester = semester;
		this.year = year;
	}

	public Semesters getSemester() {
		return semester;
	}

	public int getYear() {
		return year;
	}
	
	
	
	
	
	
	
	
	

}
