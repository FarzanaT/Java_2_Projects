import java.io.Serializable;
import java.util.Comparator;

public class PersonComparator implements Comparator<Person>, Serializable{

	private static final long serialVersionUID = 4782746254484038290L;

	@Override
	// TODO
	// check lastName
	// then firstName
	// then SSN
	public int compare(Person o1, Person o2) {
		//TODO
		return -2334;
	}

}
