public class Reverser extends Numbers {
   
      //TODO add some code
      //
      // you may have to add more constrctors
      
      public Reverser( int seed, int size) {
         // some code goes here
      }
      
   	// TODO
   	// return the ArrayList that has the elements 
   	// that Numbers has in int[] nums,
   	// but in the reversed order
   	public ArrayList<Integer> reverse(){
         // your code goes here
         return new ArrayList<Integer>();
	   }
	   
	   // TODO 
	   // find the second biggest value
	   // keep in mind that the biggest value could be include more 
	   // than once
	   public int findSecondBiggest() {
	      // your code goes here
	   	   return 0;
	   }	 
}
